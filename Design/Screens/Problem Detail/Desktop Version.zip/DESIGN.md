# Design System Document: The Architectural Marketplace

## 1. Overview & Creative North Star: "The Digital Blueprint"
This design system moves beyond the "Standard SaaS" aesthetic to embrace a philosophy we call **The Digital Blueprint**. It is inspired by the precision of architectural wireframes and the clarity of high-end editorial magazines. 

The goal is to communicate "Technical Excellence" for NODUS. We achieve this not through decoration, but through **Structural Sophistication**. We utilize massive negative space as a functional element—guiding the eye toward conversion—rather than just "white space." By favoring abstract geometric shapes and wireframe aesthetics over stock photography, we position the marketplace as a tool for builders, engineers, and high-level strategists.

**Creative Principles:**
*   **Intentional Asymmetry:** Break the rigid 12-column feel. Use offset text blocks to create a rhythmic, high-end editorial flow.
*   **Structural Clarity:** Use the "No-Line" rule to define sections, relying on tonal shifts to imply boundaries.
*   **Technical Elegance:** Lean into the `electric indigo` accent sparingly to highlight "The Path of Success" (CTAs and status indicators).

---

## 2. Colors & Tonal Hierarchy
We move away from flat design by using a sophisticated spectrum of "Off-Whites" and "Cool Greys" to create depth without clutter.

### The Palette
*   **Primary (Electric Indigo):** `#3525cd` (with `#4f46e5` as the container) – Used for primary actions and active states.
*   **Surface (The Canvas):** `#f8f9fa` – The default background for the "Technical Clean" look.
*   **On-Surface (Deep Charcoal):** `#191c1d` – Used for all primary body and heading copy to ensure high-contrast readability.
*   **Neutral Layers:** A range from `surface-container-low` (`#f3f4f5`) to `surface-container-highest` (`#e1e3e4`).

### The "No-Line" Rule
**Prohibit 1px solid borders for sectioning.** Boundaries must be defined through:
1.  **Background Shifts:** Transition from `surface` to `surface-container-low` to signal a new content block.
2.  **Negative Space:** Use the spacing scale (minimum 128px between sections) to create an invisible "moat" around content.

### Glass & Gradient Rule
For floating elements (e.g., sticky navigation or hovering "Talent Cards"), use a **Glassmorphism** effect:
*   **Background:** `surface-container-lowest` at 80% opacity.
*   **Blur:** `backdrop-filter: blur(12px)`.
*   **Accent:** Use a subtle linear gradient on primary buttons: `linear-gradient(135deg, #3525cd 0%, #4f46e5 100%)`.

---

## 3. Typography: The Editorial Engine
The system uses a pairing of **Space Grotesk** (Display/Headlines) and **Inter** (Body/Labels) to balance technical precision with human readability.

*   **Display Large (`3.5rem` / Space Grotesk):** Reserved for Hero headers. Set with `letter-spacing: -0.02em` and `line-height: 1.1`.
*   **Headline Medium (`1.75rem` / Space Grotesk):** For section headers. This is the "voice" of the brand.
*   **Body Large (`1rem` / Inter):** Default text. Increase line-height to `1.7` to maximize the "premium" feel.
*   **Label Medium (`0.75rem` / Inter):** Used for metadata, breadcrumbs, and technical specs. Always uppercase with `0.05em` letter spacing.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "heavy" for an ultra-minimalist system. We use **Tonal Layering** to create hierarchy.

*   **The Layering Principle:** Place a `surface-container-lowest` (`#ffffff`) card on top of a `surface-container-low` (`#f3f4f5`) section. The 1% difference in luminosity creates a sophisticated, "paper-like" lift.
*   **Ambient Shadows:** If an element must float (e.g., a modal), use a shadow tinted with the primary color: `box-shadow: 0 20px 40px rgba(53, 37, 205, 0.04)`.
*   **The "Ghost Border" Fallback:** If accessibility requires a border, use `outline-variant` at 20% opacity. Avoid `#000000` at all costs.

---

## 5. Signature Components

### Buttons (The "Control" Elements)
*   **Primary:** Solid `primary` background, `on-primary` text. No border. `0.375rem` (md) corner radius.
*   **Secondary:** `surface-container-high` background. No border. Text color: `primary`.
*   **Tertiary (Ghost):** No background. Text color: `on-surface`. Hover state reveals a `surface-container-low` background.

### Cards & Marketplace Lists
*   **Layout:** Forbid the use of divider lines between items. 
*   **Separation:** Use vertical white space (`1.5rem` minimum) or a alternating subtle background shift between items.
*   **Hover State:** On hover, the background should shift from `surface` to `surface-container-lowest` with a very soft ambient shadow to indicate interactivity.

### Technical Graphics (Wireframes)
Instead of photos, use "Abstract Geometry" components:
*   Use `outline` (`#777587`) at 0.5px weight to create grid-line backgrounds or wireframe representations of the "Nodus" network.
*   Incorporate `primary_container` dots at grid intersections to signify "Nodes" in the marketplace.

---

## 6. Do's and Don'ts

### Do
*   **Do** prioritize the "Display-LG" typography in the Hero. Let the type be the hero image.
*   **Do** use asymmetrical layouts (e.g., text on the left 5 columns, empty space in the middle 2, and a wireframe graphic on the right 5).
*   **Do** use `primary_fixed` (`#e2dfff`) for subtle highlights or "Success" badges to keep the indigo theme present but soft.

### Don't
*   **Don't** use standard icons. Use custom, thin-stroke (1px or 1.5px) SVG icons that match the wireframe aesthetic.
*   **Don't** use "Card Shadows" for every container. Let the containers breathe and sit flat on the surface-shifts.
*   **Don't** use center-aligned text for long paragraphs. Keep it left-aligned for an authoritative, technical feel.
*   **Don't** use photography of "smiling people." Use high-fidelity wireframes of the platform's interface or abstract geometric representations of data.